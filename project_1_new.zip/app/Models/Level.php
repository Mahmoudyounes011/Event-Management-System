<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Level extends Model
{
    use HasFactory;

    public $table = 'levels';

    public $primaryKey = 'id';

    protected $fillable = ['section_category_id','level','price'];

    protected $hidden = ['section_category_id','created_at','updated_at'];

}
