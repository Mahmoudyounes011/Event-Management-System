<?php
namespace App\Services\Section;

use App\Http\Requests\DeleteSectionRequest;
use App\Models\Section;
use App\Models\User;
use App\Models\Venue;
use App\Notifications\UserNotification;
use Illuminate\Support\Facades\Notification;
use Exception;
use Illuminate\Support\Facades\Auth;

class EditSectionService
{

    public function Editsection($section_id,$request)
    {
        $section = Section::where('id', $section_id)->first();

        $venue = Venue::findOrFail($section->venue_id);

        $userId =$venue->user_id;

        $user=User::findOrFail($userId);

        $authenticatedUserId = Auth::id();

            if ($authenticatedUserId !== $user)
            {

                return response(['error' => 'Unauthorized']);
            }

        $section->name = $request->input('name');

        $section->description = $request->input('description');

        $section->save();

    }


}
