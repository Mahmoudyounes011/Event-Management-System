<?php
namespace  App\services\Feedback;

use App\Models\Role;
use App\Notifications\AdminNotification;
use App\Services\Notification\SendNotificationService;
use App\services\User\GetUserService;

class StoreFeedbackService
{
    public function storeFeedback($request)
    {

        $content = $request->validated();

        $user = GetUserService::find();

        $user->feedbacks()->create($content);

        $admins = Role::find(1)->with('users')->first();

        $message = 'Someone sent you a feedback , please check your inbox';

        (new SendNotificationService)->sendNotify($admins['users'],new AdminNotification($message));
    }

}

