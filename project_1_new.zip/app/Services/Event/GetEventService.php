<?php

namespace App\services\Event;

use App\Models\Event;
use App\Models\EventLevel;
use App\Models\Level;
use App\Models\PublicEvent;
use App\Models\Section;
use App\Models\Venue;
use App\Services\Rating\GetRatingService;
use App\Services\Section\GetSectionService;
use App\services\User\GetUserService;
use App\Services\Venue\GetVenueService;
use Exception;

class GetEventService
{

    public static function all()
    {
        $placed_events = Event::with('user','ticket','section','photos','attenders')->where('status','accepted')->where('privacy','public')->where('date','>',now())
        ->select(['id','user_id','section_id','name','description','capacity','date','start_time','period'])->paginate(5);

        foreach($placed_events as $key => $event)
        {
            $rest_capacity = $event['capacity']-count($event['attenders']);
            $event['section']['venue']['rate'] = (new GetRatingService)->get($event['section']['venue']);
            $placed_events[$key]['rest_capacity'] = $rest_capacity;
            unset($placed_events[$key]['attenders']);
            unset($event['section']['venue']['ratings']);
        }

        $unplaced_events = PublicEvent::with('user','ticket','capacity','photos','attenders')->where('privacy','public')->where('date','>',now())
        ->select(['id','user_id','latitude','longitude','name','description','date','start_time','end_time'])->paginate(5);

        foreach($unplaced_events as $key => $event)
        {
            if(isset($event['capacity']['capacity']))
            {
                $rest_capacity = $event['capacity']['capacity']-count($event['attenders']);
                $unplaced_events[$key]['rest_capacity'] = $rest_capacity;
                unset($unplaced_events[$key]['attenders']);
            }
        }

        if(!isset($placed_events[0]) && !isset($unplaced_events[0]))
            throw new Exception('There are no events');

        $events['placed'] = $placed_events;
        $events['unplaced'] = $unplaced_events;

        return $events;
    }

    public static function search($request)
    {
        $data = $request->all();

        if(!isset($data['attribute']))
            throw new Exception('There are no events');

        $placed_events = Event::with('user','ticket','section','photos','attenders');

        $placed_events = $placed_events->where('name','like',$data['attribute'].'%')->orWhere('description','like',$data['attribute'].'%')->orWhere('description','like',$data['attribute'].'%')->orWhereHas('user',function($query) use ($data)
        {
            $query->where('name','like',$data['attribute'].'%');
        });

        $placed_events = $placed_events->where('status','accepted')->where('privacy','public')->where('date','>',now())->select(['id','user_id','section_id','name','description','capacity','date','start_time','period'])->paginate(5);

        foreach($placed_events as $key => $event)
        {
            $rest_capacity = $event['capacity']-count($event['attenders']);
            $event['section']['venue']['rate'] = (new GetRatingService)->get($event['section']['venue']);
            $placed_events[$key]['rest_capacity'] = $rest_capacity;
            unset($placed_events[$key]['attenders']);
            unset($event['section']['venue']['ratings']);
        }

        $unplaced_events = PublicEvent::with('user','ticket','capacity','photos','attenders');


        $unplaced_events = $unplaced_events->where('name','like',$data['attribute'].'%')->orWhere('description','like',$data['attribute'].'%')->orWhereHas('user',function($query) use ($data)
        {
            $query->where('name','like',$data['attribute'].'%');
        });

        $unplaced_events = $unplaced_events->where('privacy','public')->where('date','>',now())->select(['id','user_id','latitude','longitude','name','description','date','start_time','end_time'])->paginate(5);

        foreach($unplaced_events as $key => $event)
        {
            if(isset($event['capacity']['capacity']))
            {
                $rest_capacity = $event['capacity']['capacity']-count($event['attenders']);
                $unplaced_events[$key]['rest_capacity'] = $rest_capacity;
                unset($unplaced_events[$key]['attenders']);
            }
        }

        if(!isset($placed_events[0]) && !isset($unplaced_events[0]))
            throw new Exception('There are no events');

        $events['placed'] = $placed_events;
        $events['unplaced'] = $unplaced_events;

        return $events;
    }

    public static function suggestions()
    {
        $placed_events = Event::with('user','ticket','section','photos','attenders')->whereHas('promotions',function($query)
        {
            $query->where('type','suggestion')->where('event_promotions.end_at','>',now());
        })
        ->select(['id','user_id','section_id','name','description','capacity','date','start_time','period'])->paginate(5);

        foreach($placed_events as $key => $event)
        {
            $rest_capacity = $event['capacity']-count($event['attenders']);
            $event['section']['venue']['rate'] = (new GetRatingService)->get($event['section']['venue']);
            $placed_events[$key]['rest_capacity'] = $rest_capacity;
            unset($placed_events[$key]['attenders']);
            unset($event['section']['venue']['ratings']);
        }

        $unplaced_events = PublicEvent::with('user','ticket','capacity','photos','attenders')->whereHas('promotions',function($query)
        {
            $query->where('type','suggestion')->where('event_promotions.end_at','>',now());
        })->select(['id','user_id','latitude','longitude','name','description','date','start_time','end_time'])->paginate(5);

        foreach($unplaced_events as $key => $event)
        {
            if(isset($event['capacity']['capacity']))
            {
                $rest_capacity = $event['capacity']['capacity']-count($event['attenders']);
                $unplaced_events[$key]['rest_capacity'] = $rest_capacity;
                unset($unplaced_events[$key]['attenders']);
            }
        }

        if(!isset($placed_events[0]) && !isset($unplaced_events[0]))
            throw new Exception('There are no events');

        $events['placed'] = $placed_events;
        $events['unplaced'] = $unplaced_events;

        return $events;
    }

    public static function find($event_id,$type='placed',$select=['id','name','description','capacity','date','start_time','period','privacy'],$with=null,$status=null)
    {
        if($type=='placed')
        {
            if(isset($with))
                $event = Event::with($with);
            if(isset($status))
            {
                if(isset($with))
                    $event = $event->where('status',$status);
                else
                    $event = Event::where('status',$status);
            }


            if(isset($event))
                $event = $event->find($event_id);
            else
                $event = Event::find($event_id);
        }
        else
        {
            if(isset($with))
                $event = PublicEvent::with($with)->select($select)->find($event_id);
            else
                $event = PublicEvent::select($select)->find($event_id);
        }

        if(!isset($event))
            throw new Exception('Event not found');

        return $event;

    }
    public static function placed_events(Section $section,$date=null)
    {
        if(isset($date))
            $events = $section->events_of_date($date)->get();
        else
            $events = $section->events;

        return $events;

    }

    public static function user_events()
    {
        $user = GetUserService::find();

        $events = [];
        $events['placed'] = $user->events()->with('pivot.level','ticket','attenders')->paginate(5);

        foreach($events['placed'] as $key => $event)
        {
            $rest_capacity = $event['capacity']-count($event['attenders']);
            $event['rest_capacity'] = $rest_capacity;
            unset($event['placed'][$key]['attenders']);
        }

        $events['unplaced'] = $user->public_events()->with('capacity','ticket','attenders')->paginate(5);

        foreach($events['unplaced'] as $key => $event)
        {
            if(isset($event['capacity']['capacity']))
            {
                $rest_capacity = $event['capacity']['capacity']-count($event['attenders']);
                $event['rest_capacity'] = $rest_capacity;
                unset($event['unplaced'][$key]['attenders']);

            }
        }

        if(!isset($events['placed'][0]) && !isset($events['unplaced'][0]))
            throw new Exception('You have not events');

        return $events;

    }

    public static function venue_requests($venue_id)
    {
        $sections = GetSectionService::all($venue_id,['requests.pivot.level','requests.ticket'],'requests',true,2);

        // if(!isset($sections[0]) || !isset($sections[0]['requests'][0]))
        //     throw new Exception('There are no requests');

        return $sections;
    }

    public static function venue_rejects($venue_id)
    {
        $sections = GetSectionService::all($venue_id,['rejects.pivot.level','rejects.ticket'],'rejects',true,2);

        // if(!isset($sections[0]) || !isset($sections[0]['rejects'][0]))
        //     throw new Exception('There are no rejected events');

        return $sections;
    }

    public static function venue_events($venue_id)
    {
        $sections = GetSectionService::all($venue_id,['events.pivot.level','events.ticket','events.user'],'events',true,2);

        // if(!isset($sections[0]) || !isset($sections[0]['events'][0]))
        //     throw new Exception('There are no events');

        return $sections;
    }
}
