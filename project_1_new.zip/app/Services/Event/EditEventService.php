<?php

namespace App\services\Event;

use App\Notifications\UserNotification;
use App\Services\Notification\SendNotificationService;
use App\Services\Payment\UpdateBalanceService;
use App\services\User\UserVerificationService;
use Exception;

class EditEventService
{

    public static function edit($request,$event_id,$result)
    {
        $event = GetEventService::find($event_id,'placed',['id','user_id','section_id','status','name','description'],['user','section','pivot.level'],'pending');

        $user = $event['user'];

        $owner = $event['section']['venue']['owner'];

        UserVerificationService::verify($owner->id);

        if($event['date'] <= now())
            $result = 'rejected';


        $reasone = $request->reasone;

        $message = 'Hello '.$user->name.", Your event with name :".$event->name." and description : ".$event->description;

        if($result=='accept')
        {
            if(isset($reasone))
                throw new Exception('You can not send reasone while you are accepted the request');

            $event->status = 'accepted';

            $message = $message." has been accepted";

        }
        else
        {
            $event->status = 'rejected';

            $message = $message." has been rejected .";

            if(isset($reasone))
                $message = $message."The reasone is : ".$reasone.'.';

            $message = $message."The cost of this event will be added to your card";

            $balance = (isset($event['pivot']) && isset($event['pivot']['level'])) ? $event['section']['price']+$event['pivot']['level']['price'] : $event['section']['price'];

            (new UpdateBalanceService)->addAfterReject($balance,$user,$owner);
        }

        $event->save();

        (new SendNotificationService)->sendNotify($user,new UserNotification($user->id,$message,'Event',$result));




    }
}
