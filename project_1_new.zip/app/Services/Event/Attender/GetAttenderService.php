<?php

namespace App\Services\Event\Attender;

use App\services\Event\GetEventService;
use App\services\User\GetUserService;
use Exception;

class GetAttenderService
{
    public static function all($type,$event_id)
    {
        $event = GetEventService::find($event_id,$type,['id','privacy'],['attenders','user'],'accepted');

        if($event['privacy'] == 'private' && $event['user']['id'] != GetUserService::find()->id)
            throw new Exception('You can not browse attenders of a private event');

        $attenders = $event->attenders()->orderByPivot('created_at')->paginate(20);

        if(!isset($attenders[0]))
            throw new Exception('There are no attenders');

        return $attenders;
    }
}
