<?php
namespace App\Services\Store;

use App\Models\Store;
use Exception;

class AddStoreService
{
    public static function add($data)
    {
        return Store::create($data);
    }
}
