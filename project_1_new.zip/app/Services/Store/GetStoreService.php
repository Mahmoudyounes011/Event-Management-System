<?php
namespace App\Services\Store;

use App\Models\Store;
use App\Services\Rating\GetRatingService;
use App\services\User\GetUserService;
use Exception;
use Illuminate\Support\Facades\DB;

class GetStoreService
{

    public static function find($store_id,$with = null)
    {
        if(isset($with))
            $store = Store::with($with)->find($store_id);
        else
            $store = Store::find($store_id);

        if(!isset($store))
            throw new Exception('Store not found');

        return $store;
    }

    public function search($name)
    {
        $stores = Store::where('name', 'like',$name.'%')->with('photos','phones','times','products.product','ratings')->paginate(10);

        foreach($stores as $key => $store)
        {
            $times = $store['times']->groupBy('day');
            unset($stores[$key]['times']);
            $stores[$key]['times'] = $times;
            $stores[$key]['rate'] = (new GetRatingService)->get($store);
            unset($stores[$key]['ratings']);

        }

        if(!isset($stores[0]))
            throw new Exception('There is no stores has this name');

        return $stores;
    }

    public static function for_user()
    {
        $owner = GetUserService::find();

        $stores = $owner->stores()->with('photos','phones','times','products.product','ratings')->paginate(10);

        foreach($stores as $key => $store)
        {
            $times = $store->times->groupBy('day');
            unset($stores[$key]->times);
            $stores[$key]->times = $times;
            $stores[$key]['rate'] = (new GetRatingService)->get($store);
            unset($stores[$key]['ratings']);
        }

        if(!isset($stores))
            throw new Exception('This owner does not have any store');

        return $stores;
    }

    public static function all()
    {
        $stores = Store::with('phones','photos','times','products.product','ratings')->paginate(10);

        foreach($stores as $key => $store)
        {
            $times = $store->times->groupBy('day');
            unset($stores[$key]->times);
            $stores[$key]->times = $times;
            $stores[$key]['rate'] = (new GetRatingService)->get($store);
            unset($stores[$key]['ratings']);

        }
        if(!isset($stores[0]))
            throw new Exception('There are no stores');

        return $stores;
    }
}
