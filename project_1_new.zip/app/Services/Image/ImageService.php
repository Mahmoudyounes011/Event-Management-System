<?php

namespace App\Services\Image;

class ImageService
{
    public static function upload_image($images,$type)
    {
        $paths = [];


        foreach($images as $image)
        {
            $paths[] = $image->store($type, 'public');
        }

        return $paths;
    }
}


