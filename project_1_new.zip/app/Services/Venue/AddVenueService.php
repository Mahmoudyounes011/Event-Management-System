<?php
namespace App\Services\Venue;

use App\Models\Venue;

class AddVenueService
{
    public static function add($data)
    {
        return Venue::create($data);
    }
}
