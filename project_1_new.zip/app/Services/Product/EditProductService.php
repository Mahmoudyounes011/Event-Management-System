<?php

namespace App\Services\Product;

use App\Models\Product;
use App\Models\Store;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Services\Image\ImageService;
use App\Services\Store\GetStoreService;
use App\services\User\UserVerificationService;
use App\Traits\AssistentFunctions;
use Exception;

class EditProductService
{
    use AssistentFunctions;

    public function Editproduct($product_id,$request)
    {

         $product = Product::where('id', $product_id)->first();

         $product->name = $request->input('name');

         $product->description = $request->input('description');

         $product->save();

    }


}
