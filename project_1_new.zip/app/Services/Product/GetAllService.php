<?php

namespace App\Services\Product;

use App\Models\Product;

use App\Traits\AssistentFunctions;
use Exception;

class GetAllService
{
    public function all()
    {
        $products = Product::all();
        if(!isset($products[0]))
            throw new Exception('There are no products');

        return $products;
    }

    public function find($ids=null)
    {
        $products = Product::whereIn('id',$ids)->get();
        if(!isset($products[0]))
            throw new Exception('There are no products');

        return $products;
    }
}
