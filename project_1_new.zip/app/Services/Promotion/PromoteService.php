<?php

namespace App\Services\Promotion;

use App\Jobs\PromotionNotifyJob;
use App\Models\Promotion;
use App\services\Event\GetEventService;
use App\Services\Payment\UpdateBalanceService;
use App\services\User\GetUserService;
use Carbon\Carbon;
use Exception;

class PromoteService
{
    public function promote($request,$promotion_id,$event_id,$event_type)
    {
        $promotion = (new GetPromotionService)->find($promotion_id);

        $hours = $request->input('hours');

        if((!isset($hours) && $promotion->type=='Suggestion') || (isset($hours) && $promotion->type=='notification'))
        throw new Exception('There is promotion error for input');

        if($event_type=='placed')
        {
            $event = GetEventService::find($event_id,'placed',['id','name','privacy','date','start_time'],null,'accepted');
        }
        else
        {
            $event = GetEventService::find($event_id,'unplaced',['id','name','privacy','date','start_time']);
        }

        if($promotion->type=='notification')
            dispatch(new PromotionNotifyJob($event));

        if($event['privacy'] == 'private')
            throw new Exception('private events can not be promoted');

        $date = Carbon::createFromFormat('Y-m-d H:i:s',$event['date'].' '.$event['start_time']);

        if($date <= now())
            throw new Exception('event can not be promoted at the date of the event');

        // if($promotion->type=='suggestion')
        //     UpdateBalanceService::pay(GetUserService::find(),$hours*$promotion->cost,GetUserService::find(1));
        // else
        //     UpdateBalanceService::pay(GetUserService::find(),$promotion->cost,GetUserService::find(1));

        $end_at = now()->addHours($hours);

        $event->promotions()->attach($promotion,['end_at' => $end_at,'created_at' => now()]);



    }
}
