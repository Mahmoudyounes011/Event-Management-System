<?php

namespace App\services\User;

use App\Models\User;
use Exception;

class GetUserService
{

    public function all()
    {
        $users = User::with('wallet')->select('id', 'name', 'email')->paginate(10);

        if(!isset($users[0]))
            throw new Exception('There are no users');

        return $users;
    }

    public function all_for_notify()
    {
        $users = User::select('id')->get();

        if(!isset($users[0]))
            throw new Exception('There are no users');

        return $users;
    }

    public static function find($id = null)
    {
        if(isset($id))
        {
            $user = User::find($id);

            if(!isset($user))
                throw new Exception('User not found');

            return $user;
        }

        return auth()->user();
    }
}
