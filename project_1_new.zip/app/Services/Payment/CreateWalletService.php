<?php

namespace App\Services\Payment;

use App\Models\User;
use App\services\User\GetUserService;
use Exception;

class CreateWalletService
{

    public static function add($user = null)
    {
        $user->wallet()->create(['balance' => 0]);
    }

}
