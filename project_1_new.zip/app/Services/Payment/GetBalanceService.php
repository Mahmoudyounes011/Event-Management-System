<?php

namespace App\Services\Payment;

use App\Models\Payment;
use App\Models\User;
use App\Models\Wallet;
use App\services\User\GetUserService;
use Exception;

class GetBalanceService
{

    public static function get($user = null)
    {

        $wallet = isset($user) ? $user->wallet : (GetUserService::find())->wallet;

        return $wallet;
    }

    public static function all()
    {

        $payements = Payment::with(['payer','payee'])->paginate(20);

        if(!isset($payements[0]))
            throw new Exception('There are no payments');
        
        return $payements;
    }

}
