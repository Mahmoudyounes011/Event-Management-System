<?php

namespace App\Http\Controllers\_Event;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateEventRequest;
use App\Http\Requests\CreatePublicPlaceEventRequest;
use App\Services\Event\Attender\GetAttenderService;
use App\services\Event\AddEventService;
use App\services\Event\Attender\RegisterEventService;
use App\services\Event\EditEventService;
use App\services\Event\GetEventService;
use App\Services\Section\GetSectionService;
use Exception;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function home(GetEventService $event)
    {

        try
        {
            $events = $event->all();
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $events
        ]);
    }

    public function suggestions(GetEventService $event)
    {

        try
        {
            $events = $event->suggestions();
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $events
        ]);
    }

    public function search(Request $request,GetEventService $event)
    {

        try
        {
            $events = $event->search($request);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $events
        ]);
    }

    public function user_events(GetEventService $event)
    {
        try
        {
            $events = $event->user_events();
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $events
        ]);
    }

    public function venue_requests($venue_id,GetEventService $event)
    {
        try
        {
            $events = $event->venue_requests($venue_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $events
        ]);
    }

    public function venue_events($venue_id,GetEventService $event)
    {
        try
        {
            $events = $event->venue_events($venue_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $events
        ]);
    }
    public function venue_rejects($venue_id,GetEventService $event)
    {
        try
        {
            $events = $event->venue_rejects($venue_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $events
        ]);
    }

    public function venue_reply($event_id,$result,Request $request,EditEventService $event)
    {
        try
        {
            $event->edit($request,$event_id,$result);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'message' => 'The reply is sent successfully'
        ]);
    }

    public function craete_placed(CreateEventRequest $request,$section_id,AddEventService $event)
    {
        try
        {
            $event->add_placed($request,$section_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'message' => 'The event is queued to owner\'s requests'
        ]);
    }

    public function craete_unplaced(CreatePublicPlaceEventRequest $request,AddEventService $event)
    {
        try
        {
            $event->add_unplaced($request);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'message' => 'The event is created successfully'
        ]);
    }

    public function register(RegisterEventService $event,$type,$event_id)
    {
        try
        {
            $event->store($type,$event_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'message' => 'The registerization is done successfully'
        ]);
    }

    public function attenders(GetAttenderService $event,$type,$event_id)
    {
        try
        {
            $attenders = $event->all($type,$event_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $attenders
        ]);
    }
}
