<?php

namespace App\Http\Section\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class SectionLevelController extends Controller
{
    //
}
