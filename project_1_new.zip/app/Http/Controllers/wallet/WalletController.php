<?php

namespace App\Http\Controllers\wallet;

use App\Http\Controllers\Controller;
use App\Http\Requests\BalanceReqeust;
use App\Models\User;
use Illuminate\Http\Request;
use App\Services\User\BalanceUserService;
use App\Http\Controllers\wallet\Auth;
use App\Services\Payment\UpdateBalanceService;
use Exception;

class WalletController extends Controller
{

    public function updateBalance(BalanceReqeust $request,$user_id, UpdateBalanceService $walletService)
    {
        try
        {
            $walletService->add($request,$user_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }
        return response([
            'status' => 'success',

        ]);
    }




    // public function addBalance(BalanceReqeust $request)
    // {
    //     $userId =$request->user_id;
    //     $amount = $request->amount;

    //     // Retrieve the user with the associated wallet
    //     $user = User::with('wallet')->findOrFail($userId);

    //     // Update the wallet's balance
    //     $user->wallet->balance += $amount;

    //     // Save the changes
    //     $user->wallet->save();

    //     return response()->json(['message' => 'Balance added successfully']);
    // }
}
