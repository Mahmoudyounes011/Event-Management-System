<?php

namespace App\Http\Store\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class StoreProductController extends Controller
{
    //
}
