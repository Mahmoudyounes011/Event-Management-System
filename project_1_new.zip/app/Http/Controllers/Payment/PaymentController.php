<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use App\Services\Payment\GetBalanceService;
use Exception;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function get_all(GetBalanceService $payement)
    {
        $payments = $payement->all();
        try
        {
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $payments
        ]);
    }
}
