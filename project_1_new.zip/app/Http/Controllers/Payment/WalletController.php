<?php

namespace App\Http\Payment\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class WalletController extends Controller
{
    //
}
