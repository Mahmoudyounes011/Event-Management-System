<?php

namespace App\Http\Controllers\Product;

use App\Http\Requests\EditRequest;
use App\Services\Product\EditProductService;
use App\Http\Controllers\Controller;
use App\Http\Requests\AddProductRequest;
use App\Models\Store;
use App\Services\Product\AddProductService;
use App\Services\Product\GetAllService;
use Exception;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    public function get_all(GetAllService $all)
    {
        try
        {
            $products = $all->all();
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $products
        ]);
    }
    public function add_from_store($store_id,AddProductRequest $request,AddProductService $add)
    {
        try
        {
            $add->add($store_id,$request);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'message' => 'the products are stored successfully'
        ]);
    }


    public function update(EditRequest $request,EditProductService $product,$product_id)
    {

        try
        {
            $product->Editproduct($product_id, $request);

            $stores = Store::select('stores.id as store_id', 'users.id as user_id')
                ->join('store_products', 'stores.id', '=', 'store_products.store_id')
                ->join('users', 'stores.user_id', '=', 'users.id')
                ->where('store_products.product_id', $product_id)
                ->get();

            $user_id = $stores->first()->user_id;

            $authenticatedUserId = Auth::id();

            if ($authenticatedUserId !== $user_id)
            {
                    return response(['error' => 'Unauthorized']);
            }
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }
        return response([
            'status' => 'success',

        ]);
    }


}
