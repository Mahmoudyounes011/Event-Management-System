<?php

namespace App\Http\Controllers\FeedBack;

use App\Http\Controllers\Controller;
use App\Http\Requests\FeedbackRequest;
use App\services\Feedback\DeleteFeedbackService;
use App\services\Feedback\feedbackService;
use App\services\Feedback\GetFeedbackService;
use App\services\Feedback\StoreFeedbackService;
use Exception;
use Illuminate\Http\Request;
class FeedbackController extends Controller
{
    public function store(FeedbackRequest $request, StoreFeedbackService $feedbackService)
    {
        try
        {

            $feedbackService->storeFeedback($request);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'message' => 'Feedback submitted successfully',
        ]);
    }

    public function get_all_feedbacks(GetFeedbackService $feedback)
    {
        try
        {
            $feedbacks = $feedback->all();
        }
        catch(Exception $e)
        {
            return response(['status' => 'fail','message' => $e->getMessage()]);
        }

        return response(['status' => 'success','data' =>  $feedbacks]);
    }

    public function mark_as_read(DeleteFeedbackService $feedback,$feedback_id)
    {
        try
        {
            $feedbacks = $feedback->delete($feedback_id);
        }
        catch(Exception $e)
        {
            return response(['status' => 'fail','message' => $e->getMessage()]);
        }

        return response(['status' => 'success','message' => 'the feedback is deleted successfuy']);
    }

}
