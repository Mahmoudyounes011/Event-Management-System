<?php

namespace App\Http\Controllers\Order;

use App\Http\Controllers\Controller;
use App\Http\Requests\AddOrderRequest;
use App\services\Order\EditOrderService;
use App\services\Order\GetOrderService;
use App\services\Order\StoreOrderService;
use Exception;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function add(AddOrderRequest $request,$store_id,StoreOrderService $order)
    {
        try
        {
            $order->add($request,$store_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => 'the order is sent successfully'
        ]);
    }

    public function store_requests($store_id,GetOrderService $order)
    {
        try
        {
            $orders = $order->store_requests($store_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $orders
        ]);
    }

    public function store_rejects($store_id,GetOrderService $order)
    {
        try
        {
            $orders = $order->store_rejects($store_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $orders
        ]);
    }

    public function store_orders($store_id,GetOrderService $order)
    {
        try
        {
            $orders = $order->store_orders($store_id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => $orders
        ]);
    }

    public function store_reply($order_id,$result,Request $request,EditOrderService $order)
    {
        try
        {
            $order->edit($request,$order_id,$result);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'message' => 'The reply is sent successfully'
        ]);
    }
}
