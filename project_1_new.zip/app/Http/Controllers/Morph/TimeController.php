<?php

namespace App\Http\Controllers\Morph;

use App\Http\Controllers\Controller;
use App\Http\Requests\TimeScheduleRequest;
use App\Services\Time\StoreTimeScheduleService;
use Exception;

class TimeController extends Controller
{
    public function add_time_schedule($type,$id,TimeScheduleRequest $request)
    {
        try
        {
            StoreTimeScheduleService::store($request,$type,$id);
        }
        catch(Exception $e)
        {
            return response([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

        return response([
            'status' => 'success',
            'data' => 'TimeSchedule is added successfuly'
        ]);
    }
}
