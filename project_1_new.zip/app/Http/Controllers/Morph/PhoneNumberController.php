<?php

namespace App\Http\Morph\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class PhoneNumberController extends Controller
{
    //
}
