<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\services\User\GetUserService;
use Exception;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function get_all_users(GetUserService $user)
    {
        try
        {
            $users = $user->all();
        }
        catch(Exception $e)
        {
            return response(['status' => 'fail','message' => $e->getMessage()]);
        }

        return response(['status' => 'success','data' =>  $users]);
    }
}
