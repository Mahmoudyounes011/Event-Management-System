<?php

namespace App\Http\User\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class AttenderController extends Controller
{
    //
}
