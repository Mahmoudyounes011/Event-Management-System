<?php

namespace App\Http\Photo\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class ImageController extends Controller
{
    //
}
